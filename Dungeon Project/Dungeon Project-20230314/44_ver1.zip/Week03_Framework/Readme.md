用CMake執行

main.cpp 在 Week03 裡面
.exe 檔及 Source code 放在 /44_ver1/submit 資料夾內

工作分配:
B11130008徐欣儀 50%
B11115037莊靜雯 50%