#pragma once
#include <string>
#include <iostream>
#include "Position.h"
#include "Hero.h"


//************************************************************
// Trigger Class
//************************************************************
class Trigger {
	// Implement Trigger Class
	/*Please implement your code here*/

	/************************************************************************/
};

