.exe 檔及 Source code(main.cpp, main.h, Hero.h, Trigger.h, Position.h 檔) 在 /44_ver1/submit 資料夾內
Readme.md 檔及 工作分配.md 檔在 /44_ver1 資料夾內

可以用CMake執行