/************************************************************************
File:   Source.cpp

Author:
		���ſ��Atbcey74123@gmail.com
Comment:
		Output character position after W,A,S,D input.
		Output invalid if destination out of boundary.
		ESC to stop process.

************************************************************************/
#include <iostream>	// For print out information
#include <conio.h>	// For getch() function

bool tryMove(int deltaX, int deltaY);
bool checkValidDst(int x, int y);

int posX = 0, posY = 0; // global param to keep the character position
const int DUNGEN_SIZE = 5; // For each dimension, -DUNGEN_SIZE < pos < DUNGEN_SIZE

int main() {
	// Obtain and update the input using a loop
	while (true) {
		char input = _getch();

		/************************************************************************/
		/*Please implement your code here*/


		/************************************************************************/
	}
}

//******************************************************************
//
// * Move character with input delta, return true if successful otherwise false
//==================================================================
bool tryMove(int deltaX, int deltaY) {
	/************************************************************************/
	/*Please implement your code here*/

	/************************************************************************/
}
//******************************************************************
//
// * Check if given position is a valid destination, return true if valid otherwise false
//==================================================================
bool checkValidDst(int x, int y) {
	/************************************************************************/
	/*Please implement your code here*/

	/************************************************************************/
}
