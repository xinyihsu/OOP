用CMake執行

main.cpp 在 Week02 裡面